#!/usr/bin/env python3
"""Read-only validation of this planning export, not UE or full-repository validation.

No network, installation, copying, mutation, commits, or pushes. --repo additionally
checks local task-file collisions; it does not inspect un-fetched remote branches.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys
from typing import Any

ID = re.compile(r'TASK-\d{3,}\Z')
CASE = re.compile(r'T(\d{3,})-C\d{2,}\Z')
LISTS = ('source_refs','dependencies','blocked_by','contracts','allowed_paths','forbidden_paths','acceptance','non_goals','required_tests')


def load(path: Path) -> Any:
    def no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in pairs:
            if key in value:
                raise ValueError(f'duplicate JSON key: {key}')
            value[key] = item
        return value
    def bad_constant(value: str) -> Any:
        raise ValueError(f'non-finite JSON constant: {value}')
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=no_duplicates, parse_constant=bad_constant)


def safe_path(value: Any) -> bool:
    if not isinstance(value,str) or not value or value.strip()!=value:
        return False
    if value.startswith('/') or '\\' in value or re.match(r'^[A-Za-z]:',value) or any(c in value for c in '*?[]\x00\r\n'):
        return False
    return all(p not in ('','.', '..') for p in value.rstrip('/').split('/'))


def scope_conflict(allow: str, deny: str) -> bool:
    # A containing allowed directory also intersects a forbidden child directory.
    return (allow == deny or (deny.endswith('/') and allow.startswith(deny))
            or (allow.endswith('/') and deny.startswith(allow)))


def validate(root: Path, repo: Path | None=None) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    plan=root/'docs/planning/TASK-112-133'
    try:
        index=load(plan/'INDEX.json')
        cases=load(plan/'CASE_MATRIX.json')
    except (OSError, ValueError, UnicodeError) as exc:
        return {'status':'FAIL','errors':[f'Cannot read package index/cases: {exc}'],'warnings':warnings}
    tasks: dict[str,dict[str,Any]]={}
    for path in sorted((root/'docs/tasks').glob('TASK-*.json')):
        try:
            task=load(path)
            if not isinstance(task,dict): raise ValueError('task must be object')
            tid=task.get('id','')
            if not isinstance(tid,str) or not ID.fullmatch(tid): raise ValueError('invalid task ID')
            if tid in tasks: raise ValueError('duplicate task ID')
            if path.stem!=tid: errors.append(f'{path.name}: filename/ID mismatch')
            tasks[tid]=task
            if task.get('schema_version')!=1: errors.append(f'{tid}: schema_version != 1')
            if task.get('status')!='Backlog': errors.append(f'{tid}: planning status must be Backlog')
            if task.get('owner')!='XLingyyy' or task.get('reviewer') is not None: errors.append(f'{tid}: owner/reviewer mismatch')
            if task.get('issue_url') is not None: errors.append(f'{tid}: uncreated Issue must be null')
            if not str(task.get('branch','')).startswith(f'codex/{tid}-'): errors.append(f'{tid}: proposed branch mismatch')
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',str(task.get('updated_at',''))): errors.append(f'{tid}: invalid date')
            for key in LISTS:
                value=task.get(key)
                if not isinstance(value,list) or any(not isinstance(v,str) or not v for v in value): errors.append(f'{tid}: bad {key}')
            for key in ('source_refs','allowed_paths','acceptance','required_tests'):
                if not task.get(key): errors.append(f'{tid}: empty {key}')
            for key in ('allowed_paths','forbidden_paths'):
                for p in task.get(key,[]):
                    if not safe_path(p): errors.append(f'{tid}: unsafe {key} {p!r}')
            for allow in task.get('allowed_paths',[]):
                for deny in task.get('forbidden_paths',[]):
                    if scope_conflict(allow,deny): errors.append(f'{tid}: overlapping allowed/forbidden {allow} vs {deny}')
            if 'README.md' not in task.get('allowed_paths',[]): errors.append(f'{tid}: README scope missing')
            for rel in task.get('contracts',[]):
                if not safe_path(rel) or not (root/rel).is_file(): errors.append(f'{tid}: missing/unsafe contract {rel}')
            perms=task.get('permissions',{})
            for key in ('network','install_dependencies','commit','push','merge'):
                if not isinstance(perms.get(key),str) or not perms[key]: errors.append(f'{tid}: missing permission {key}')
            for key in ('commit','push','merge','github_release'):
                if not perms.get(key,'').startswith('not_granted'): errors.append(f'{tid}: planning cannot grant {key}')
            if task.get('prototype_only') is not False: errors.append(f'{tid}: unexpected prototype metadata')
            for rel in (f'docs/tasks/{tid}.md',f'docs/handoffs/{tid}.md'):
                if not (root/rel).is_file(): errors.append(f'{tid}: missing {rel}')
        except (OSError, ValueError, UnicodeError, TypeError) as exc:
            errors.append(f'{path.name}: {exc}')
    expected={f'TASK-{n}' for n in range(112,134)}
    if set(tasks)!=expected: errors.append('Task set is not exactly TASK-112—133')
    index_tasks=index.get('tasks',[])
    if len(index_tasks)!=22 or {t.get('id') for t in index_tasks}!=expected: errors.append('Index/task set mismatch')
    for it in index_tasks:
        tid=it.get('id')
        if tid in tasks and it.get('dependencies')!=tasks[tid].get('dependencies'): errors.append(f'{tid}: index dependency mismatch')
    done:set[str]=set(); active:set[str]=set()
    def visit(tid:str) -> None:
        if tid in active:
            errors.append(f'Dependency cycle: {tid}');return
        if tid in done: return
        active.add(tid)
        for dep in tasks[tid].get('dependencies',[]):
            if dep not in tasks: errors.append(f'{tid}: unknown dependency {dep}')
            else:visit(dep)
        active.remove(tid);done.add(tid)
    for tid in tasks:visit(tid)
    counts={tid:0 for tid in tasks}; seen:set[str]=set()
    if not isinstance(cases,list): cases=[];errors.append('Case matrix must be a list')
    for c in cases:
        cid=c.get('id','');tid=c.get('task','')
        if cid in seen or not CASE.fullmatch(cid): errors.append(f'Bad/duplicate case ID: {cid}')
        seen.add(cid)
        if tid not in tasks: errors.append(f'{cid}: unknown task')
        else:
            counts[tid]+=1
            if not cid.startswith(f'T{tid[5:]}-'): errors.append(f'{cid}: task/ID mismatch')
            if not any(cid in a for a in tasks[tid]['acceptance']): errors.append(f'{cid}: missing in task acceptance')
            md=root/f'docs/tasks/{tid}.md'
            if md.is_file() and cid not in md.read_text(encoding='utf-8'): errors.append(f'{cid}: absent from Markdown')
        if c.get('status')!='NOT_RUN' or c.get('evidence') is not None: errors.append(f'{cid}: planned game test incorrectly marked executed')
        if c.get('layer') not in ('DOC','NATIVE','PIE','SAVE','PLAY','AUDIO','PERF'):errors.append(f'{cid}: unknown layer')
        if not c.get('steps') or not c.get('expected'):errors.append(f'{cid}: empty procedure/expected')
    if len(cases)!=132 or any(v!=6 for v in counts.values()):errors.append('Expected 132 cases, 6 per task')
    # Check relative file links in the exported Markdown. Directory-only references are valid.
    for path in root.rglob('*.md'):
        for match in re.finditer(r'!?\[[^\]\n]*\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            target=match.group(1)
            if ':' in target or target.startswith('#'):continue
            rel=target.split('#',1)[0]
            if rel and not (path.parent/rel).exists():errors.append(f'{path.relative_to(root)}: broken link {target}')
    if repo is not None:
        if not repo.is_dir() or not (repo/'.git').exists(): errors.append('--repo is not a local Git repository root')
        else:
            for tid in sorted(expected):
                for rel in (f'docs/tasks/{tid}.json',f'docs/tasks/{tid}.md',f'docs/handoffs/{tid}.md'):
                    if (repo/rel).exists():errors.append(f'Local target collision: {rel}')
            warnings.append('Remote branches, current authorization, worktree edits and LFS locks are NOT checked.')
    warnings.extend(['This validates the planning package only, NOT scripts/validate_repo.py for the complete repository.',
                     'No UE build, gameplay, model, audio, performance, human or second-machine test was run.'])
    return {'status':'PASS' if not errors else 'FAIL','scope':'planning-package-structure-only','task_count':len(tasks),'case_count':len(cases),'all_cases_not_run':all(c.get('status')=='NOT_RUN' for c in cases),'dependency_graph_acyclic':not any('cycle' in e for e in errors),'errors':errors,'warnings':warnings}


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--repo',type=Path,help='Optional local repository root for collision checks; no mutation.')
    args=parser.parse_args()
    result=validate(args.root.resolve(),args.repo.resolve() if args.repo else None)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':
    sys.exit(main())
