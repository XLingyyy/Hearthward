# TASK-105 测试矩阵

所有UE项当前NOT_RUN；仅新Python工具20项已有实际PASS。以下是运行清单，不是代填验收。

|编号/过滤器后缀|验证内容|状态|
|---|---|---|
|Index.IdentityAndMiss|原行对象、命中、miss清除、源数组不变|NOT_RUN|
|Index.DuplicatesAndCaseMatchLegacy|重复项取首个；大小写/中文与原FString线性查找逐项一致|NOT_RUN|
|Index.NonIdAndMalformedFallback|未知/坏类型/缺ID表保留原错误路径；空表正常miss|NOT_RUN|
|Index.RootIsolation|两个目录实例独立，无全局串数据|NOT_RUN|
|Index.ProductionCatalogEquivalence|真实一般目录与战役目录全行对照|NOT_RUN|
|Campaign.CountsTrackCurrentState|组过滤、生命变化、删除、组变更立即反映|NOT_RUN|
|Campaign.VictoryAndStrict95Percent|80/84/88、严格95%、增援终态与存活敌人|NOT_RUN|
|Python test_catalog_ids.py|20项工具逻辑与CLI正反例|PASS，独立日志|
|正式目录校验|实际gameplay.json的12张ID表|NOT_RUN|
|既有全仓工具测试|完整仓库上的unittest discover|NOT_RUN|
|UE Build＋既有回归|Editor/Shipping、战役、库存、存档|NOT_RUN|
|整段实玩＋性能|新档/继续、伙伴/两营地、双后端同版矩阵|NOT_RUN|

UE完整前缀为 `Hearthward.Engineering.Task105.`。测试不要用只返回true的替身或Python镜像算法替代。读取/保存原件按既有只读副本纪律执行。
