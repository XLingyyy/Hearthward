from pathlib import Path
import json,shutil,subprocess,sys,tempfile,unittest
PACKAGE=Path(__file__).resolve().parent
class SafePatchTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'repo';self.root.mkdir()
  self.pkg=Path(self.tmp.name)/'package';self.pkg.mkdir()
  shutil.copytree(PACKAGE/'original',self.root,dirs_exist_ok=True)
  (self.root/'Hearthward.uproject').write_text('{"test_fixture_only": true}\n')
  self.git('init','--initial-branch=main');self.git('config','user.email','fixture@example.invalid');self.git('config','user.name','Patch Test Fixture')
  self.git('add','.');self.git('commit','-m','Synthetic isolated fixture, not Hearthward main')
  for name in ['TASK-105.patch','manifest.json']:shutil.copyfile(PACKAGE/name,self.pkg/name)
  shutil.copytree(PACKAGE/'payload',self.pkg/'payload')
  m=json.loads((self.pkg/'manifest.json').read_text());m['base_commit']=self.git('rev-parse','HEAD').stdout.strip()
  (self.pkg/'manifest.json').write_text(json.dumps(m))
 def git(self,*a):return subprocess.run(['git','-C',str(self.root),*a],check=True,capture_output=True,text=True,timeout=20)
 def run_tool(self,*a):return subprocess.run([sys.executable,str(PACKAGE/'apply_patch.py'),'--repo',str(self.root),'--package',str(self.pkg),*a],capture_output=True,text=True,encoding='utf-8',timeout=30)
 def test_check_is_read_only(self):
  before=self.git('rev-parse','HEAD').stdout
  r=self.run_tool();self.assertEqual(r.returncode,0,r.stderr)
  self.assertEqual(self.git('status','--porcelain').stdout,'');self.assertEqual(self.git('branch','--show-current').stdout.strip(),'main');self.assertEqual(self.git('rev-parse','HEAD').stdout,before)
 def test_apply_stages_exact_payload_and_reverses(self):
  r=self.run_tool('--apply','--editor-closed');self.assertEqual(r.returncode,0,r.stderr)
  self.assertEqual(self.git('branch','--show-current').stdout.strip(),'codex/TASK-105-engineering-optimization')
  m=json.loads((self.pkg/'manifest.json').read_text())
  self.assertEqual(set(self.git('diff','--cached','--name-only').stdout.splitlines()),set(m['files']))
  for rel in m['files']:self.assertEqual((self.root/rel).read_bytes(),(self.pkg/'payload'/rel).read_bytes())
  self.git('apply','--reverse','--check',str(self.pkg/'TASK-105.patch'))
 def test_editor_confirmation_required(self):
  r=self.run_tool('--apply');self.assertNotEqual(r.returncode,0);self.assertIn('editor',r.stderr.lower());self.assertEqual(self.git('status','--porcelain').stdout,'')
 def test_dirty_tracked_tree_rejected(self):
  with (self.root/'README.md').open('a') as f:f.write('\nprivate edit\n')
  r=self.run_tool('--apply','--editor-closed');self.assertNotEqual(r.returncode,0);self.assertIn('private edit',(self.root/'README.md').read_text())
 def test_untracked_work_rejected(self):
  (self.root/'work.txt').write_text('keep me');r=self.run_tool('--apply','--editor-closed')
  self.assertNotEqual(r.returncode,0);self.assertEqual((self.root/'work.txt').read_text(),'keep me')
 def test_new_head_rejected(self):
  self.git('commit','--allow-empty','-m','Another developer');r=self.run_tool('--apply','--editor-closed')
  self.assertNotEqual(r.returncode,0);self.assertIn('HEAD differs',r.stderr)
 def test_existing_branch_not_overwritten(self):
  self.git('branch','codex/TASK-105-engineering-optimization');r=self.run_tool('--apply','--editor-closed')
  self.assertNotEqual(r.returncode,0);self.assertEqual(self.git('branch','--show-current').stdout.strip(),'main')
 def test_tampered_patch_rejected(self):
  with (self.pkg/'TASK-105.patch').open('a') as f:f.write('\nchanged\n')
  r=self.run_tool();self.assertNotEqual(r.returncode,0);self.assertIn('hash mismatch',r.stderr)
 def test_tampered_payload_rejected(self):
  (self.pkg/'payload'/'README.md').write_text('changed')
  r=self.run_tool();self.assertNotEqual(r.returncode,0);self.assertIn('hash mismatch',r.stderr)
 def test_wrong_game_root_rejected(self):
  self.git('rm','Hearthward.uproject');self.git('commit','-m','Remove game marker')
  r=self.run_tool();self.assertNotEqual(r.returncode,0);self.assertIn('game root',r.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
