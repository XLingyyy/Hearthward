# Hearthward TASK-105｜工程优化候选与内容规划交付

日期：2026-10-11。此包是源码候选，不是已经编译的游戏更新，也不是远端 PR。

## 交付状态

GitHub 连接可以读取仓库，但创建 `codex/TASK-105-engineering-optimization` 时返回 403 `Resource not accessible by integration`。未创建远端分支、提交或 PR，未合并 main、未发布新版本、未修改任何连接权限。

补丁严格绑定已读取的 main 提交：

`ff5f6f985b326011b9dc968ebe9ace55f4582088`

包含共享目录索引、一般/战役目录接入、不复制敌人数组的战役计数、只读数据检查器、7 项 UE 测试源，以及任务/QA/工程与内容规划。没有改动存档格式、玩法数值、AI 参数与安全边界、UE 二进制资产、输入配置、依赖或 CI 工作流。新增内容仍为规划，未在游戏里制作。

## 文件用途

- `TASK-105.patch`：15 个文件的统一补丁，保留原路径。
- `payload/`：这些文件的完整修改版；用于审查，不建议手工覆盖整个目录。
- `original/`：三份实际被修改文件的精确审查基线；仅供补丁测试/比对，不用于回退玩家工程。
- `manifest.json`：基线提交、原文件 Git blob、修改后文件与补丁 SHA256。
- `apply_patch.py`：默认只检查；只有显式授权参数才创建本地分支并应用/暂存。
- `test_apply_package.py`：在临时合成 Git 仓库内测试应用工具，不运行游戏，也不触碰用户仓库。
- `qa/`：本次工具测试与应用安全测试的真实日志；不代表 UE 构建结果。
- `payload/docs/planning/TASK-105/CONTENT_ROADMAP.md`：与另行交付的 18 页 DOCX 相同的内容规划。
- `payload/docs/planning/TASK-105/ENGINEERING_PLAN.md`：本次改动边界与后续工程路线。

## 应用前提

需要已安装的 Git 和 Python 3.10 或更高版本（本次工具测试在 Python 3.13.5/Linux 执行）。脚本不安装依赖。游戏工程应为完整克隆；包解压在工程目录外，避免未跟踪文件阻止检查。

先保存并关闭目标工程的 UE 编辑器，保留其他工作树的改动和玩家存档。脚本会拒绝非游戏根目录、不同 HEAD、已有未提交/未跟踪改动、已有同名任务分支，以及文件/补丁身份不一致。不要为了通过检查执行 reset、clean 或覆盖既有工作。

## 第一步：默认只读核对

在本包目录运行，把路径替换为实际 Hearthward 游戏仓库根目录，而不是上层 GameFactory：

```text
python apply_patch.py --repo "G:\GameFactory\Hearthward"
```

只有输出 `CHECK PASS` 才说明精确基线、工作树、文件身份、补丁路径及 `git apply --check` 通过。此时没有创建分支或改动仓库。

若 HEAD 已更新，停止并在新主干上审查/移植本补丁；不要把仓库重置回此基线。若 TASK-105 已被其他人使用，先协调任务编号及全部引用，不强占编号。

## 第二步：显式应用

确认目标 UE 编辑器已保存关闭、只读检查通过后运行：

```text
python apply_patch.py --repo "G:\GameFactory\Hearthward" --apply --editor-closed
```

脚本创建本地 `codex/TASK-105-engineering-optimization` 分支并执行 `git apply --index`。修改进入暂存区，**不会自动提交、推送或合并**。`--editor-closed` 是操作者的确认，不代表脚本能够探测编辑器未保存状态。

若创建分支后应用失败，脚本停止，不自动 reset/clean 或切回；先检查当前分支和工作树，保留现场。

## 第三步：完整工程验证

在游戏仓库内依照现有 AGENTS/BUILD_AND_TEST 和任务范围执行：

```text
python scripts/agent_context.py --task TASK-105
python scripts/qa/validate_catalog_ids.py --json
python -m unittest discover -s scripts/tests -p test_catalog_ids.py -v
python scripts/validate_repo.py
python scripts/validate_repo.py --task TASK-105 --base ff5f6f985b326011b9dc968ebe9ace55f4582088
python -m unittest discover -s scripts/tests -v
```

UE 操作沿仓库 `docs/qa/BUILD_AND_TEST.md` 的 GameFactory UEClient 公开入口，显式指定此游戏工程。完成 UE 5.8.2 Editor 编译，再运行 `Hearthward.Engineering.Task105.`（应发现 7 项）及既有战役、装备、库存、存档回归，之后做同版 Shipping 冒烟与自然连续流程。具体矩阵在 `payload/docs/qa/TASK-105/TEST_MATRIX.md`。

目录成员和 ID 必须在进程内不变。若完整工程审查发现运行时写表/改 ID 或热重载，必须先补正确重建机制，不能直接合并此缓存假设。没有真实帧时间、内存数据前，不宣称 FPS 提升。

## 本次真实测试与边界

|检查|结果|范围|
|---|---|---|
|新增目录校验工具|20/20 PASS|Python 单元测试、CLI 正反例及只读性|
|补丁应用工具|10/10 PASS|临时合成 Git 夹具，精确应用/反向检查、脏树/错基线/已有分支/篡改拒绝|
|三份原文件身份|PASS|Git blob 与远端读取结果一致|
|7 项新 UE 原生用例|NOT_RUN|已编写源码；不是 Python 测试|
|正式 gameplay.json 全量检查|NOT_RUN|未把合成数据当作生产表|
|完整仓库检查与既有工具全集|NOT_RUN|当前环境未取得完整克隆|
|UE 编译、Shipping、帧率、真人/二机|NOT_RUN|当前环境无项目 Windows UE/MSVC 工具链|
|远端提交/PR|BLOCKED_403|没有远端写入|

补丁工具测试可在本包内复跑：

```text
python test_apply_package.py
```

该命令只创建临时合成仓库并清理自己的临时目录，不验证游戏行为。20 项与 10 项属于两个独立测试集合，不合并成游戏验收成绩。

## 后续提交

上述验证通过并由有权限的操作者审查后，按项目流程提交任务分支、推送并创建 PR。不要在没有 UE 编译与回归的情况下直接更新 main。恢复 GitHub 连接的仓库写入权限应通过正常授权流程完成，不要把私人令牌放进源码、文档或聊天。
