#!/usr/bin/env python3
"""Check a Hearthward patch package; apply only with explicit --apply --editor-closed.

Creates a task branch and stages the patch, but never commits, pushes, merges,
fetches, resets, cleans, changes permissions or touches player saves.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

class PatchError(RuntimeError):
    pass

def git(root: Path, *args: str, ok_codes=(0,)) -> subprocess.CompletedProcess:
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    try:
        result = subprocess.run(["git", "-C", str(root), *args], capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=30, env=env)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PatchError(f"Git command could not run: {args[0]} ({type(exc).__name__})") from exc
    if result.returncode not in ok_codes:
        raise PatchError(f"Git {args[0]} failed ({result.returncode}); inspect the repository before proceeding.")
    return result

def safe_relative(value: str) -> bool:
    p = PurePosixPath(value)
    return bool(value) and not p.is_absolute() and "\\" not in value and ":" not in value and not any(x in {"", ".", ".."} for x in value.split("/"))

def check(root: Path, package: Path) -> tuple[dict, Path]:
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or not re.fullmatch(r"[a-f0-9]{40}", manifest.get("base_commit", "")):
        raise PatchError("Invalid package manifest or base identity.")
    name = manifest.get("patch", "")
    if not safe_relative(name):
        raise PatchError("Unsafe patch path.")
    patch = (package / name).resolve()
    if not patch.is_relative_to(package) or hashlib.sha256(patch.read_bytes()).hexdigest() != manifest.get("patch_sha256"):
        raise PatchError("Patch hash mismatch; do not apply a modified package.")
    entries = manifest.get("files")
    if not isinstance(entries, dict) or not entries:
        raise PatchError("Missing file manifest.")
    for rel, identity in entries.items():
        if not isinstance(rel, str) or not safe_relative(rel):
            raise PatchError("Unsafe payload path.")
        source = (package / "payload" / rel).resolve()
        if not source.is_relative_to(package / "payload") or not source.is_file():
            raise PatchError(f"Missing or unsafe payload: {rel}")
        if hashlib.sha256(source.read_bytes()).hexdigest() != identity.get("sha256"):
            raise PatchError(f"Payload hash mismatch: {rel}")
    if Path(git(root, "rev-parse", "--show-toplevel").stdout.strip()).resolve() != root:
        raise PatchError("--repo must be the game repository root.")
    if not (root / "Hearthward.uproject").is_file():
        raise PatchError("Hearthward.uproject is missing; this is not the game root.")
    if git(root, "status", "--porcelain", "--untracked-files=all").stdout.strip():
        raise PatchError("Repository has tracked or untracked changes. Preserve them; do not reset or clean.")
    if git(root, "rev-parse", "HEAD").stdout.strip() != manifest["base_commit"]:
        raise PatchError("HEAD differs from the reviewed base. Review/rebase the patch; do not reset the repository.")
    for rel, identity in entries.items():
        target = root / rel
        if target.is_symlink():
            raise PatchError(f"Refusing symlink target: {rel}")
        before = identity.get("before_blob")
        if before is None:
            if target.exists():
                raise PatchError(f"New path already exists: {rel}")
        else:
            actual = git(root, "hash-object", f"--path={rel}", "--", rel).stdout.strip()
            if actual != before:
                raise PatchError(f"Reviewed source identity mismatch: {rel}")
    # Cross-check actual patch scope, rather than trusting the file list alone.
    stats = git(root, "apply", "--numstat", "-z", str(patch)).stdout
    paths = {entry.split("\t", 2)[2] for entry in stats.split("\0") if entry}
    if paths != set(entries):
        raise PatchError("Patch path list does not match manifest.")
    git(root, "apply", "--check", str(patch))
    return manifest, patch

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--editor-closed", action="store_true", help="Confirm the target project's UE Editor is closed; this script cannot verify unsaved editor state")
    args = parser.parse_args(argv)
    try:
        root, package = args.repo.resolve(), args.package.resolve()
        if args.apply and not args.editor_closed:
            raise PatchError("Close/save the target UE Editor, then explicitly pass --editor-closed.")
        manifest, patch = check(root, package)
        if not args.apply:
            print("CHECK PASS: reviewed base, clean tree, file hashes, scope and git apply --check. No writes made.")
            return 0
        branch = manifest.get("branch", "")
        if not branch.startswith("codex/TASK-105-"):
            raise PatchError("Unexpected task branch in manifest.")
        git(root, "check-ref-format", "--branch", branch)
        exists = git(root, "show-ref", "--verify", "--quiet", "refs/heads/" + branch, ok_codes=(0, 1))
        if exists.returncode == 0:
            raise PatchError("Task branch already exists. Do not overwrite; review its work first.")
        git(root, "switch", "-c", branch)
        git(root, "apply", "--index", str(patch))
        print(f"APPLIED AND STAGED on {branch}. Not committed or pushed. UE build and regression are still required.")
        return 0
    except (PatchError, OSError, UnicodeError, ValueError, KeyError, TypeError, IndexError) as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
